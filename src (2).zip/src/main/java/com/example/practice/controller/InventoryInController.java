package com.example.practice.controller;

public class InventoryInController {

}

