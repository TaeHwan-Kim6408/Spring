package oracle.jdbc.driver;

import java.sql.Driver;

public class OracleDriver implements Driver {
}
