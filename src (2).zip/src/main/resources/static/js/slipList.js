let currentPage = 1;
const itemsPerPage = 5;

async function fetchPendingCount() {
    try {
        const response = await fetch('/api/vouchers/pending/count');
        const data = await response.json();

        const pendingCountElement = document.getElementById('pendingCount');
        if (pendingCountElement) {
            // number 타입을 String 타입으로 변환하여 할당
            pendingCountElement.textContent = String(data.count || 0);
        } else {
            console.error('Element with id "pendingCount" not found.');
        }
    } catch (error) {
        console.error('Error fetching pending count:', error);
    }
}

async function fetchPendingVouchers(page = 1) {
    try {
        const response = await fetch(`/api/vouchers/pending?page=${page}&limit=${itemsPerPage}`);
        const data = await response.json();
        const voucherList = document.getElementById('voucherList');
        voucherList.innerHTML = '';

        if (data.data && data.data.length > 0) {
            data.data.forEach(voucher => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${voucher.ID || 'N/A'}</td>
                    <td>${voucher.등록일자 || 'N/A'}</td>
                    <td>${voucher.거래처명 || 'N/A'}</td>
                    <td>${voucher.계정코드 || 'N/A'}</td>
                    <td>${(voucher.금액 && !isNaN(voucher.금액) ? voucher.금액.toLocaleString() : '0').toLocaleString()}원</td>
                    <td>${voucher.거래형태 || 'N/A'}</td>
                    <td>${voucher.적요 || 'N/A'}</td>
                    <td>${voucher.작성자 || 'N/A'}</td>
                    <td>${voucher.상태 || 'N/A'}</td>
                `;
                voucherList.appendChild(row);
            });
        } else {
            // 데이터가 없을 경우
            const row = document.createElement('tr');
            row.innerHTML = '<td colspan="9" style="text-align:center;">No vouchers found</td>';
            voucherList.appendChild(row);
        }

        document.getElementById('currentPage').textContent = page.toString();
    } catch (error) {
        console.error('Error fetching pending vouchers:', error);
    }
}

function changePage(direction) {
    if (direction === 'prev' && currentPage > 1) {
        currentPage--;
    } else if (direction === 'next') {
        currentPage++;
    }

    // fetchPendingVouchers 결과를 처리하기 위해 .then()에서 적절한 로직 추가
    fetchPendingVouchers(currentPage)
        .then(() => {
            // 페이지를 성공적으로 가져왔을 때 실행할 코드 (예: 화면에 결과 표시)
            console.log(`현재 페이지: ${currentPage}`);
        })
        .catch((error) => {
            console.error('Error fetching vouchers:', error);
        });
}

function initializePage() {
    return fetchPendingCount()
        .then(() => fetchPendingVouchers(currentPage));
}

// initialize Page를 호출할 때 .then() 체이닝을 사용하여 프로미스 처리
initializePage().then(() => {
    console.log('페이지 초기화가 완료되었습니다.');
}).catch(error => {
    console.error('페이지 초기화 중 오류 발생:', error);
});

// 전송할 데이터 정의
const data = {
    key1: 'value1',
    key2: 'value2'
};

// 데이터를 보내는 함수
async function fetchData() {
    try {
        // fetch 호출
        const response = await fetch('/some-api', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json; charset=UTF-8'
            },
            body: JSON.stringify(data)
        });

        // 응답 확인: 상태 코드가 200 OK일 때만 처리
        if (!response.ok) {
            console.error('Network response was not ok:', response.statusText);
            throw new Error(`Network response was not ok ${response.statusText}`);
        }

        // 응답 데이터를 JSON으로 변환
        const responseData = await response.json();

        // 성공적으로 데이터를 받아왔을 때 처리
        console.log('응답 데이터:', responseData);
    } catch (error) {
        // 에러 처리: 네트워크 에러나 JSON 파싱 에러 등
        console.error('데이터 가져오기 오류:', error);
    }
}

fetchData();

    document.getElementById('showSlipSectionButton').addEventListener('click', function() {
    var slipSection = document.getElementById('slipSection');
    slipSection.style.display = 'block'; // 전표 등록 폼을 보이게 함
});


