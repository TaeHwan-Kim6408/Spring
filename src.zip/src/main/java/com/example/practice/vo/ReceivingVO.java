package com.example.practice.vo;

@Date
public class ReceivingVO {

    String product_code;
    String product_name;
    int store_quantity;
    int sale_price;
    int price;
    String category_code;


    public void setId(int id) {
    }
}
