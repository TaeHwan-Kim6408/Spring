package com.example.practice.service;

import com.example.practice.vo.ReceivingVO;

import java.util.List;

public interface IF_ReceivingService {

    List<ReceivingVO> selectAll(ReceivingVO receivingvo) throws Exception;
    void insertReceiving(ReceivingVO receivingvo) throws Exception;
    void deleteReceiving(ReceivingVO receivingvo) throws Exception;
    void updateReceiving(ReceivingVO receivingvo) throws Exception;
}
