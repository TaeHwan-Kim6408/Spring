package com.example.practice.service;

import com.example.practice.model.InventoryIn;
import com.example.practice.repository.IF_InventoryInDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventoryInService {

	@Autowired
	private IF_InventoryInDao inventoryInDao;

	public List<InventoryIn> getAllInventoryIn() {
		return inventoryInDao.findAll();
	}

	public void addInventoryIn(InventoryIn inventoryIn) {
		inventoryInDao.insert(inventoryIn);
	}

	public InventoryIn getInventoryInById(Long id) {
		return inventoryInDao.findById(id);
	}

	public void updateInventoryIn(InventoryIn inventoryIn) {  // 올바른 메서드명
		inventoryInDao.update(inventoryIn);
	}

	public void deleteInventoryIn(Long id) {
		inventoryInDao.delete(id);
	}
}
