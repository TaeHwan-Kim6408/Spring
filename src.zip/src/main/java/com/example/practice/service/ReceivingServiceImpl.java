package com.example.practice.service;

import com.example.practice.repository.IF_ReceivingDao;
import com.example.practice.vo.ReceivingVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReceivingServiceImpl implements IF_ReceivingService {

    private final IF_ReceivingDao receivingDao;

    @Autowired
    public ReceivingServiceImpl(IF_ReceivingDao receivingDao) {
        this.receivingDao = receivingDao;
    }

    @Override
    public List<ReceivingVO> selectAll(ReceivingVO receivingvo) throws Exception {
        return receivingDao.selectAll(receivingvo);
    }
    @Override
    public void insertReceiving(ReceivingVO receivingvo) throws Exception {
        receivingDao.insertReceiving(receivingvo);
    }

    @Override
    public void deleteReceiving(ReceivingVO receivingvo) throws Exception {
        receivingDao.deleteReceiving(receivingvo);
    }

    @Override
    public void updateReceiving(ReceivingVO receivingvo) throws Exception {
        receivingDao.updateReceiving(receivingvo);
    }
}
