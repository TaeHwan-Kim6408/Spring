package com.example.practice.controller;

import com.example.practice.service.IF_ReceivingService;
import com.example.practice.vo.ReceivingVO;
import lombok.RequiredArgsConstructor;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping
@RequiredArgsConstructor
public class ReceivingController {

    private final IF_ReceivingService receivingService;

    // 입고 등록 화면 이동
    @RequestMapping("/receiving")
    public String receiving() throws Exception {
        return "receiving";
    }

    // 입고 등록
    @PostMapping("/receiving")
    public String receiving(@ModelAttribute ReceivingVO receivingvo) throws Exception {
        receivingService.insertReceiving(receivingvo);
        return "redirect:receiving";
    }

    // 입고 확인
    @GetMapping("/receivinglistview")
    public String receiving(Model model, @ModelAttribute ReceivingVO receivingvo) throws Exception {
        List<ReceivingVO> Receivinglist = receivingService.selectAll(receivingvo);
        model.addAttribute("receivinglist", Receivinglist);
        return "receivinglist";
    }

    @DeleteMapping("receiving/{id}")
    public String receivingDelete(@PathVariable int id) throws Exception {
        ReceivingVO receivingvo = new ReceivingVO();
        receivingvo.setId(id);
        receivingService.deleteReceiving(receivingvo);
        return "redirect:receiving";
    }

    @PutMapping
    public String receivingUpdate(@ModelAttribute ReceivingVO receivingvo) throws Exception {
        receivingvo.setId(id);
        receivingService.updateReceiving(receivingvo);
        return "redirect:receiving";
    }
}
