package com.example.practice.repository;

import com.example.practice.model.InventoryIn;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface IF_InventoryInDao {

    // 전체 입고 데이터 조회
    @Select("SELECT * FROM inventory_in")
    List<InventoryIn> findAll();

    // 특정 ID의 입고 데이터 조회
    @Select("SELECT * FROM inventory_in WHERE id = #{id}")
    InventoryIn findById(Long id);

    // 입고 데이터 삽입
    @Insert("INSERT INTO inventory_in (product_name, quantity, price, received_date) VALUES (#{productName}, #{quantity}, #{price}, #{receivedDate})")
    void insert(InventoryIn inventoryIn);

    // 입고 데이터 업데이트
    @Update("UPDATE inventory_in SET product_name = #{productName}, quantity = #{quantity}, price = #{price}, received_date = #{receivedDate} WHERE id = #{id}")
    void update(InventoryIn inventoryIn);

    // 입고 데이터 삭제
    @Delete("DELETE FROM inventory_in WHERE id = #{id}")
    void delete(Long id);
}

