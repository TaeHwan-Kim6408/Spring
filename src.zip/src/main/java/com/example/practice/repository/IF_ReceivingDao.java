package com.example.practice.repository;

import com.example.practice.vo.ReceivingVO;
import org.springframework.stereotype.Repository;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
@Repository
public interface IF_ReceivingDao {

    List<ReceivingVO> selectAll(ReceivingVO receivingvo) throws Exception;

    void insertReceiving(ReceivingVO receivingvo) throws Exception;

    void deleteReceiving(ReceivingVO receivingvo) throws Exception;

    void updateReceiving(ReceivingVO receivingvo) throws Exception;

}
