
const btn = document.getElementById("popupBtn");
const modal = document.getElementById("modalWrap");
const closeBtn = document.getElementById("closeBtn");
const backBtn = document.getElementById("backBtn");

btn.onclick = function () {
    modal.style.display = "block";
}

closeBtn.onclick = function () {
    modal.style.display = "none";
}

window.onclick = function (event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

backBtn.onclick = function () {

}
