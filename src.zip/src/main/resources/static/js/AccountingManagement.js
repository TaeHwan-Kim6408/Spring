const accountsByType = {
    sales: ["제품 매출", "서비스 매출", "기타 수익", "이자 수익", "외상매출금", "매출채권"],
    cost: ["급여비", "임금비", "소모품비", "광고비", "인쇄비", "판매비", "운송비", "관리비", "기타 관리비", "감가상각비"],
    asset: ["재고자산", "기계장비", "감가상각누계액"],
    liability: ["단기부채 이자", "장기부채 이자", "미지급 비용", "미지급 급여"]
};

// 섹션 열기
const menuLink = document.getElementById("showSlipSectionButton");
const slipSection = document.getElementById("slipSection");

menuLink.onclick = function (e) {
    e.preventDefault();
    slipSection.style.display = "block";
    document.getElementById("slipForm").reset(); // 폼 초기화
};

// 계정과목 옵션 업데이트 함수
function updateAccountOptions() {
    const slipType = document.getElementById("slipType").value;
    const accountSelect = document.getElementById("accountType");

    // 기존 옵션 제거
    accountSelect.innerHTML = '<option value="">선택하세요</option>';

    // 선택된 전표 타입에 따른 계정과목 추가
    if (slipType && accountsByType[slipType]) {
        accountsByType[slipType].forEach(account => {
            const option = document.createElement("option");
            option.value = account;
            option.textContent = account;
            accountSelect.appendChild(option);
        });
    }
}

// 부가세 계산 함수
function calculateVat() {
    const amount = parseFloat(document.getElementById("amount").value) || 0;
    const slipType = document.getElementById("slipType").value;
    const accountType = document.getElementById("accountType").value;

    if ((slipType === 'sales' && accountType.includes('매출')) ||
        (slipType === 'cost' && accountType.includes('매입'))) {
        document.getElementById("vat").value = Math.round(amount * 0.1);
    } else {
        document.getElementById("vat").value = 0;
    }
}