
// 환영 메시지 설정
const userId = "홍길동"; // 실제 로그인한 아이디로 변경 필요
document.getElementById("welcome-message").textContent = `${userId}님, 환영합니다!`;